import json, io
if __name__ == "__main__":
	"""
	a = open("a.txt", "w")
	b = open("b.txt", "w")
	c = open("c.txt", "w")
	d = open("d.txt", "w")
	e = open("e.txt", "w")
	f = open("f.txt", "w")
	g = open("g.txt", "w")
	h = open("h.txt", "w")
	i = open("i.txt", "w")
	j = open("j.txt", "w")
	k = open("k.txt", "w")
	l = open("l.txt", "w")
	m = open("m.txt", "w")
	n = open("n.txt", "w")
	o = open("o.txt", "w")
	p = open("p.txt", "w")
	q = open("q.txt", "w")
	r = open("r.txt", "w")
	s = open("s.txt", "w")
	t = open("t.txt", "w")
	u = open("u.txt", "w")
	v = open("v.txt", "w")
	w = open("w.txt", "w")
	x = open("x.txt", "w")
	y = open("y.txt", "w")
	z = open("z.txt", "w")
	"""
	ind = open("IoT.json", "w")
	ha = dict()
	c = 0
	i = 0
	with io.open("9906TokenDocId.txt", "rt", newline="\n") as words:
		check = words.readline()
		words.seek(0, 0)
		for line in words:
			x = line.split(" ->")[0]
			print(x)
			ha[x] = c+i
			#i+=1
			c += len(line)

	json.dump(ha, ind)




